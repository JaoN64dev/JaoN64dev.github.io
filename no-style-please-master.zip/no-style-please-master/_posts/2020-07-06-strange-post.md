---
layout: post
custom_js: mouse_coords
---

This post is strange. It also has some custom js.